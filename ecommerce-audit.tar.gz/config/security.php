<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Rate Limiting
    |--------------------------------------------------------------------------
    |
    | All limits are configurable through .env.
    |
    */

    'rate_limits' => [

        /*
        |--------------------------------------------------------------------------
        | AUTHENTICATION
        |--------------------------------------------------------------------------
        */

        'auth' => [

            'ip' => [
                'max_attempts' => (int) env(
                    'RATE_LIMIT_AUTH_IP_MAX',
                    10
                ),

                'decay_seconds' => (int) env(
                    'RATE_LIMIT_AUTH_IP_DECAY',
                    60
                ),
            ],

            'account' => [
                'max_attempts' => (int) env(
                    'RATE_LIMIT_AUTH_ACCOUNT_MAX',
                    5
                ),

                'decay_seconds' => (int) env(
                    'RATE_LIMIT_AUTH_ACCOUNT_DECAY',
                    300
                ),
            ],

            'base_backoff_seconds' => (int) env(
                'RATE_LIMIT_AUTH_BACKOFF_BASE',
                2
            ),

            'max_backoff_seconds' => (int) env(
                'RATE_LIMIT_AUTH_BACKOFF_MAX',
                300
            ),
        ],

        /*
        |--------------------------------------------------------------------------
        | REGISTRATION
        |--------------------------------------------------------------------------
        */

        'registration' => [

            'max_attempts' => (int) env(
                'RATE_LIMIT_REGISTER_MAX',
                5
            ),

            'decay_seconds' => (int) env(
                'RATE_LIMIT_REGISTER_DECAY',
                900
            ),

            'base_backoff_seconds' => (int) env(
                'RATE_LIMIT_REGISTER_BACKOFF_BASE',
                2
            ),

            'max_backoff_seconds' => (int) env(
                'RATE_LIMIT_REGISTER_BACKOFF_MAX',
                300
            ),
        ],

        /*
        |--------------------------------------------------------------------------
        | PASSWORD RESET
        |--------------------------------------------------------------------------
        */

        'password_reset' => [

            'ip' => [
                'max_attempts' => (int) env(
                    'RATE_LIMIT_RESET_IP_MAX',
                    5
                ),

                'decay_seconds' => (int) env(
                    'RATE_LIMIT_RESET_IP_DECAY',
                    300
                ),
            ],

            'account' => [
                'max_attempts' => (int) env(
                    'RATE_LIMIT_RESET_ACCOUNT_MAX',
                    3
                ),

                'decay_seconds' => (int) env(
                    'RATE_LIMIT_RESET_ACCOUNT_DECAY',
                    900
                ),
            ],

            'base_backoff_seconds' => (int) env(
                'RATE_LIMIT_RESET_BACKOFF_BASE',
                5
            ),

            'max_backoff_seconds' => (int) env(
                'RATE_LIMIT_RESET_BACKOFF_MAX',
                300
            ),
        ],

        /*
        |--------------------------------------------------------------------------
        | EMAIL VERIFICATION
        |--------------------------------------------------------------------------
        */

        'verification' => [

    'max_attempts' => (int) env(
        'RATE_LIMIT_VERIFICATION_MAX',
        5
    ),

    'decay_seconds' => (int) env(
        'RATE_LIMIT_VERIFICATION_DECAY',
        300
    ),

    'account_max_attempts' => (int) env(
        'RATE_LIMIT_VERIFICATION_ACCOUNT_MAX',
        5
    ),

    'account_decay_seconds' => (int) env(
        'RATE_LIMIT_VERIFICATION_ACCOUNT_DECAY',
        300
    ),

    'base_backoff_seconds' => (int) env(
        'RATE_LIMIT_VERIFICATION_BACKOFF_BASE',
        5
    ),

    'max_backoff_seconds' => (int) env(
        'RATE_LIMIT_VERIFICATION_BACKOFF_MAX',
        300
    ),
],

        /*
        |--------------------------------------------------------------------------
        | PUBLIC
        |--------------------------------------------------------------------------
        */

        'public' => [

            'max_attempts' => (int) env(
                'RATE_LIMIT_PUBLIC_MAX',
                60
            ),

            'decay_seconds' => (int) env(
                'RATE_LIMIT_PUBLIC_DECAY',
                60
            ),

            'base_backoff_seconds' => (int) env(
                'RATE_LIMIT_PUBLIC_BACKOFF_BASE',
                1
            ),

            'max_backoff_seconds' => (int) env(
                'RATE_LIMIT_PUBLIC_BACKOFF_MAX',
                30
            ),
        ],

        /*
        |--------------------------------------------------------------------------
        | SENSITIVE
        |--------------------------------------------------------------------------
        */

        'sensitive' => [

            'max_attempts' => (int) env(
                'RATE_LIMIT_SENSITIVE_MAX',
                20
            ),

            'decay_seconds' => (int) env(
                'RATE_LIMIT_SENSITIVE_DECAY',
                60
            ),

            'base_backoff_seconds' => (int) env(
                'RATE_LIMIT_SENSITIVE_BACKOFF_BASE',
                2
            ),

            'max_backoff_seconds' => (int) env(
                'RATE_LIMIT_SENSITIVE_BACKOFF_MAX',
                60
            ),
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Strict Input Validation
    |--------------------------------------------------------------------------
    */

    'validation' => [

        'name' => [
            'min' => 2,
            'max' => 100,
        ],

        'email' => [
            'max' => 254,
        ],

        'password' => [
            'min' => 8,
            'max' => 128,
        ],

        'verification_code' => [
            'length' => 6,
        ],

        'reset_token' => [
            'max' => 512,
        ],
    ],
];