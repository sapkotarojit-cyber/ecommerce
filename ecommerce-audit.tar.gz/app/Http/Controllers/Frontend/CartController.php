<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use App\Models\Cart;
use App\Models\ProductVarient;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CartController extends Controller
{
    /**
     * Display user's cart
     */
    public function index()
    {
        $cartItems = Cart::where('user_id', Auth::id())
            ->with(['product', 'varient', 'dokan'])
            ->get();

        $total = 0;
        $vendorTotal = [];

        foreach ($cartItems as $item) {
            $price = $item->varient->price ?? 0;
            $discount = $item->varient->discount ?? 0;

            $finalPrice = $price - ($price * $discount / 100);
            $itemTotal = $finalPrice * $item->qty;

            $total += $itemTotal;

            // Group by vendor
            $vendorId = $item->dokan_id;

            if (! isset($vendorTotal[$vendorId])) {
                $vendorTotal[$vendorId] = [
                    'dokan' => $item->dokan,
                    'subtotal' => 0,
                    'items' => [],
                ];
            }

            $vendorTotal[$vendorId]['subtotal'] += $itemTotal;
            $vendorTotal[$vendorId]['items'][] = $item;
        }

        return view(
            'frontend.cart.index',
            compact('cartItems', 'total', 'vendorTotal')
        );
    }

    /**
     * Add item to cart
     */
    public function add(Request $request)
    {
        $validated = $request->validate([
            'varient_id' => [
                'required',
                'integer',
                'min:1',
                'exists:product_varients,id',
            ],
            'qty' => [
                'required',
                'integer',
                'min:1',
                'max:9999',
            ],
        ]);

        $varient = ProductVarient::with('product.dokan')
            ->findOrFail($validated['varient_id']);

        $qty = $validated['qty'];

        // Check stock
        if ($varient->qty < $qty) {
            if ($request->ajax() || $request->wantsJson()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Not enough stock available. Only '
                        . $varient->qty
                        . ' left.',
                ], 422);
            }

            return back()->with(
                'error',
                'Not enough stock available. Only '
                . $varient->qty
                . ' left.'
            );
        }

        // Check if item already exists in cart
        $existing = Cart::where('user_id', Auth::id())
            ->where('varient_id', $varient->id)
            ->first();

        if ($existing) {
            $newQty = $existing->qty + $qty;

            if ($varient->qty < $newQty) {
                if ($request->ajax() || $request->wantsJson()) {
                    return response()->json([
                        'success' => false,
                        'message' => 'Not enough stock available. You already have '
                            . $existing->qty
                            . ' in cart.',
                    ], 422);
                }

                return back()->with(
                    'error',
                    'Not enough stock available. You already have '
                    . $existing->qty
                    . ' in cart.'
                );
            }

            $existing->qty = $newQty;
            $existing->save();

            $message = 'Cart updated successfully!';
        } else {
            Cart::create([
                'user_id' => Auth::id(),
                'varient_id' => $varient->id,
                'product_id' => $varient->product_id,
                'dokan_id' => $varient->product->dokan_id,
                'qty' => $qty,
            ]);

            $message = 'Item added to cart successfully!';
        }

        // Return JSON response for AJAX/Fetch
        if ($request->ajax() || $request->wantsJson()) {
            $cartCount = Cart::where('user_id', Auth::id())
                ->sum('qty');

            return response()->json([
                'success' => true,
                'message' => $message,
                'cart_count' => $cartCount,
            ]);
        }

        return redirect()
            ->route('cart.index')
            ->with('success', $message);
    }

    /**
     * Buy now: Add item to cart and redirect straight to checkout.
     */
    public function buyNow(Request $request)
    {
        $validated = $request->validate([
            'varient_id' => [
                'required',
                'integer',
                'min:1',
                'exists:product_varients,id',
            ],
            'qty' => [
                'required',
                'integer',
                'min:1',
                'max:9999',
            ],
        ]);

        $variant = ProductVarient::with('product.dokan')
            ->findOrFail($validated['varient_id']);

        $qty = $validated['qty'];

        $existing = Cart::where('user_id', Auth::id())
            ->where('varient_id', $variant->id)
            ->first();

        $newQty = $qty;

        if ($existing) {
            $newQty = $existing->qty + $qty;
        }

        /*
         * Make sure total cart quantity doesn't exceed stock.
         */
        if ($newQty > $variant->qty) {
            return response()->json([
                'success' => false,
                'message' => "Only {$variant->qty} items are available "
                    . "in stock. You already have "
                    . ($existing->qty ?? 0)
                    . " in your cart.",
            ], 422);
        }

        if ($existing) {
            $existing->update([
                'qty' => $newQty,
            ]);
        } else {
            Cart::create([
                'user_id' => Auth::id(),
                'product_id' => $variant->product_id,
                'varient_id' => $variant->id,
                'dokan_id' => $variant->product->dokan_id ?? null,
                'qty' => $qty,
            ]);
        }

        /*
         * Select only this item for checkout.
         */
        $cart = Cart::where('user_id', Auth::id())
            ->where('varient_id', $variant->id)
            ->firstOrFail();

        session([
            'checkout_cart_ids' => [$cart->id],
        ]);

        return response()->json([
            'success' => true,
            'redirect_url' => route('orders.checkout'),
        ]);
    }

    /**
     * Update cart item quantity
     */
    public function update(Request $request, $id)
    {
        $validated = $request->validate([
            'qty' => [
                'required',
                'integer',
                'min:1',
                'max:9999',
            ],
        ]);

        $cart = Cart::where('id', $id)
            ->where('user_id', Auth::id())
            ->firstOrFail();

        $variant = ProductVarient::findOrFail($cart->varient_id);

        $qty = $validated['qty'];

        // Check available stock
        if ($qty > $variant->qty) {
            return response()->json([
                'success' => false,
                'message' => "Only {$variant->qty} items are available in stock.",
            ], 422);
        }

        $cart->update([
            'qty' => $qty,
        ]);

        $cartCount = Cart::where('user_id', Auth::id())
            ->sum('qty');

        return response()->json([
            'success' => true,
            'message' => 'Cart updated successfully.',
            'qty' => $qty,
            'cart_count' => $cartCount,
        ]);
    }

    /**
     * Remove item from cart
     */
    public function destroy($id)
    {
        $cartItem = Cart::where('id', $id)
            ->where('user_id', Auth::id())
            ->firstOrFail();

        $cartItem->delete();

        if (request()->ajax() || request()->wantsJson()) {
            return response()->json([
                'success' => true,
                'message' => 'Item removed from cart!',
            ]);
        }

        return redirect()
            ->route('cart.index')
            ->with('success', 'Item removed from cart.');
    }

    /**
     * Clear entire cart
     */
    public function clear()
    {
        Cart::where('user_id', Auth::id())->delete();

        return redirect()
            ->route('cart.index')
            ->with('success', 'Cart cleared successfully!');
    }

    /**
     * Get cart count
     */
    public function count()
    {
        $count = Cart::where('user_id', Auth::id())
            ->sum('qty');

        if (request()->ajax() || request()->wantsJson()) {
            return response()->json([
                'count' => $count,
            ]);
        }

        return $count;
    }
}