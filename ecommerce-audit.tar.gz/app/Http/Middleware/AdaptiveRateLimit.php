<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Cache\RateLimiter;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Symfony\Component\HttpFoundation\Response;

class AdaptiveRateLimit
{
    public function __construct(
        private RateLimiter $limiter
    ) {
    }

    public function handle(
        Request $request,
        Closure $next,
        string $profile = 'public'
    ): Response {
        $config = config("security.rate_limits.{$profile}");

        if (!is_array($config)) {
            abort(
                500,
                "Rate limit profile [{$profile}] is not configured."
            );
        }

        return match ($profile) {
            'auth' => $this->handleAuthentication(
                $request,
                $next,
                $config
            ),

            'registration' => $this->handleAccountProfile(
                $request,
                $next,
                $config,
                'registration'
            ),

            'password_reset' => $this->handlePasswordReset(
                $request,
                $next,
                $config
            ),

            'verification' => $this->handleVerification(
                $request,
                $next,
                $config
            ),

            default => $this->handleStandard(
                $request,
                $next,
                $config
            ),
        };
    }

    /*
    |--------------------------------------------------------------------------
    | STANDARD / PUBLIC / SENSITIVE
    |--------------------------------------------------------------------------
    */

    private function handleStandard(
        Request $request,
        Closure $next,
        array $config
    ): Response {
        $route = $request->route()?->getName()
            ?? $request->path();

        $key = $this->key(
            'ip',
            $request->ip(),
            $route
        );

        $retryAfter = $this->checkAndRecord(
            $key,
            $this->requiredInt(
                $config,
                'max_attempts'
            ),
            $this->requiredInt(
                $config,
                'decay_seconds'
            ),
            $this->requiredInt(
                $config,
                'base_backoff_seconds'
            ),
            $this->requiredInt(
                $config,
                'max_backoff_seconds'
            )
        );

        if ($retryAfter !== null) {
            return $this->tooManyRequests(
                $retryAfter
            );
        }

        return $next($request);
    }

    /*
    |--------------------------------------------------------------------------
    | AUTHENTICATION
    |--------------------------------------------------------------------------
    |
    | IP + account limits.
    |
    */

    private function handleAuthentication(
        Request $request,
        Closure $next,
        array $config
    ): Response {
        $route = $request->route()?->getName()
            ?? $request->path();

        $ipConfig = $this->requiredArray(
            $config,
            'ip'
        );

        $accountConfig = $this->requiredArray(
            $config,
            'account'
        );

        $retryAfter = null;

        /*
         * IP based protection
         */
        $ipKey = $this->key(
            'auth-ip',
            $request->ip(),
            $route
        );

        $wait = $this->checkAndRecord(
            $ipKey,
            $this->requiredInt(
                $ipConfig,
                'max_attempts'
            ),
            $this->requiredInt(
                $ipConfig,
                'decay_seconds'
            ),
            $this->requiredInt(
                $config,
                'base_backoff_seconds'
            ),
            $this->requiredInt(
                $config,
                'max_backoff_seconds'
            )
        );

        if ($wait !== null) {
            $retryAfter = $wait;
        }

        /*
         * Account/email based protection
         */
        $account = $this->accountIdentifier(
            $request
        );

        if ($account !== null) {

            $accountKey = $this->key(
                'auth-account',
                $account,
                $route
            );

            $wait = $this->checkAndRecord(
                $accountKey,
                $this->requiredInt(
                    $accountConfig,
                    'max_attempts'
                ),
                $this->requiredInt(
                    $accountConfig,
                    'decay_seconds'
                ),
                $this->requiredInt(
                    $config,
                    'base_backoff_seconds'
                ),
                $this->requiredInt(
                    $config,
                    'max_backoff_seconds'
                )
            );

            if ($wait !== null) {
                $retryAfter = max(
                    $retryAfter ?? 0,
                    $wait
                );
            }
        }

        if ($retryAfter !== null) {
            return $this->tooManyRequests(
                $retryAfter
            );
        }

        return $next($request);
    }

    /*
    |--------------------------------------------------------------------------
    | REGISTRATION
    |--------------------------------------------------------------------------
    */

    private function handleAccountProfile(
        Request $request,
        Closure $next,
        array $config,
        string $prefix
    ): Response {
        $route = $request->route()?->getName()
            ?? $request->path();

        $key = $this->key(
            $prefix . '-ip',
            $request->ip(),
            $route
        );

        $wait = $this->checkAndRecord(
            $key,
            $this->requiredInt(
                $config,
                'max_attempts'
            ),
            $this->requiredInt(
                $config,
                'decay_seconds'
            ),
            $this->requiredInt(
                $config,
                'base_backoff_seconds'
            ),
            $this->requiredInt(
                $config,
                'max_backoff_seconds'
            )
        );

        if ($wait !== null) {
            return $this->tooManyRequests(
                $wait
            );
        }

        return $next($request);
    }

    /*
    |--------------------------------------------------------------------------
    | PASSWORD RESET
    |--------------------------------------------------------------------------
    */

    private function handlePasswordReset(
        Request $request,
        Closure $next,
        array $config
    ): Response {
        $route = $request->route()?->getName()
            ?? $request->path();

        $ipConfig = $this->requiredArray(
            $config,
            'ip'
        );

        $accountConfig = $this->requiredArray(
            $config,
            'account'
        );

        $retryAfter = null;

        /*
         * IP
         */
        $ipKey = $this->key(
            'password-reset-ip',
            $request->ip(),
            $route
        );

        $wait = $this->checkAndRecord(
            $ipKey,
            $this->requiredInt(
                $ipConfig,
                'max_attempts'
            ),
            $this->requiredInt(
                $ipConfig,
                'decay_seconds'
            ),
            $this->requiredInt(
                $config,
                'base_backoff_seconds'
            ),
            $this->requiredInt(
                $config,
                'max_backoff_seconds'
            )
        );

        if ($wait !== null) {
            $retryAfter = $wait;
        }

        /*
         * Account/email
         */
        $account = $this->accountIdentifier(
            $request
        );

        if ($account !== null) {

            $accountKey = $this->key(
                'password-reset-account',
                $account,
                $route
            );

            $wait = $this->checkAndRecord(
                $accountKey,
                $this->requiredInt(
                    $accountConfig,
                    'max_attempts'
                ),
                $this->requiredInt(
                    $accountConfig,
                    'decay_seconds'
                ),
                $this->requiredInt(
                    $config,
                    'base_backoff_seconds'
                ),
                $this->requiredInt(
                    $config,
                    'max_backoff_seconds'
                )
            );

            if ($wait !== null) {
                $retryAfter = max(
                    $retryAfter ?? 0,
                    $wait
                );
            }
        }

        if ($retryAfter !== null) {
            return $this->tooManyRequests(
                $retryAfter
            );
        }

        return $next($request);
    }

    /*
    |--------------------------------------------------------------------------
    | EMAIL VERIFICATION
    |--------------------------------------------------------------------------
    */

    private function handleVerification(
        Request $request,
        Closure $next,
        array $config
    ): Response {
        $route = $request->route()?->getName()
            ?? $request->path();

        $ipConfig = $this->requiredArray(
            $config,
            'ip'
        );

        $accountConfig = $this->requiredArray(
            $config,
            'account'
        );

        $retryAfter = null;

        /*
         * IP
         */
        $ipKey = $this->key(
            'verification-ip',
            $request->ip(),
            $route
        );

        $wait = $this->checkAndRecord(
            $ipKey,
            $this->requiredInt(
                $ipConfig,
                'max_attempts'
            ),
            $this->requiredInt(
                $ipConfig,
                'decay_seconds'
            ),
            $this->requiredInt(
                $config,
                'base_backoff_seconds'
            ),
            $this->requiredInt(
                $config,
                'max_backoff_seconds'
            )
        );

        if ($wait !== null) {
            $retryAfter = $wait;
        }

        /*
         * Account
         */
        $account = $this->verificationAccountIdentifier(
            $request
        );

        if ($account !== null) {

            $accountKey = $this->key(
                'verification-account',
                $account,
                $route
            );

            $wait = $this->checkAndRecord(
                $accountKey,
                $this->requiredInt(
                    $accountConfig,
                    'max_attempts'
                ),
                $this->requiredInt(
                    $accountConfig,
                    'decay_seconds'
                ),
                $this->requiredInt(
                    $config,
                    'base_backoff_seconds'
                ),
                $this->requiredInt(
                    $config,
                    'max_backoff_seconds'
                )
            );

            if ($wait !== null) {
                $retryAfter = max(
                    $retryAfter ?? 0,
                    $wait
                );
            }
        }

        if ($retryAfter !== null) {
            return $this->tooManyRequests(
                $retryAfter
            );
        }

        return $next($request);
    }

    /*
    |--------------------------------------------------------------------------
    | RATE LIMIT CHECK
    |--------------------------------------------------------------------------
    */

    private function checkAndRecord(
        string $key,
        int $maxAttempts,
        int $decaySeconds,
        int $baseBackoffSeconds,
        int $maxBackoffSeconds
    ): ?int {
        $maxAttempts = max(
            1,
            $maxAttempts
        );

        $decaySeconds = max(
            1,
            $decaySeconds
        );

        $baseBackoffSeconds = max(
            1,
            $baseBackoffSeconds
        );

        $maxBackoffSeconds = max(
            $baseBackoffSeconds,
            $maxBackoffSeconds
        );

        /*
         * Existing backoff
         */
        $backoffKey = $key . '|backoff-until';

        $backoffUntil = Cache::get(
            $backoffKey
        );

        if (is_numeric($backoffUntil)) {

            $remaining =
                (int) $backoffUntil -
                now()->timestamp;

            if ($remaining > 0) {
                return min(
                    $maxBackoffSeconds,
                    $remaining
                );
            }

            Cache::forget(
                $backoffKey
            );
        }

        /*
         * Current attempts
         */
        $attempts = $this->limiter->attempts(
            $key
        );

        if ($attempts >= $maxAttempts) {

            $strikeKey =
                $key . '|strikes';

            $strikes = (int) Cache::get(
                $strikeKey,
                0
            );

            $strikes++;

            Cache::put(
                $strikeKey,
                $strikes,
                $decaySeconds
            );

            /*
             * Exponential backoff:
             *
             * strike 1 = base
             * strike 2 = base * 2
             * strike 3 = base * 4
             * strike 4 = base * 8
             */

            $exponent = min(
                20,
                max(
                    0,
                    $strikes - 1
                )
            );

            $retryAfter = min(
                $maxBackoffSeconds,
                $baseBackoffSeconds *
                (2 ** $exponent)
            );

            $retryAfter = max(
                1,
                $retryAfter
            );

            Cache::put(
                $backoffKey,
                now()
                    ->addSeconds($retryAfter)
                    ->timestamp,
                $retryAfter
            );

            return $retryAfter;
        }

        /*
         * Record request
         */
        $this->limiter->hit(
            $key,
            $decaySeconds
        );

        return null;
    }

    /*
    |--------------------------------------------------------------------------
    | ACCOUNT IDENTIFIER
    |--------------------------------------------------------------------------
    */

    private function accountIdentifier(
        Request $request
    ): ?string {
        $email = $request->input('email');

        if (
            !is_string($email) ||
            trim($email) === ''
        ) {
            return null;
        }

        return hash(
            'sha256',
            mb_strtolower(
                trim($email)
            )
        );
    }

    /*
    |--------------------------------------------------------------------------
    | VERIFICATION ACCOUNT IDENTIFIER
    |--------------------------------------------------------------------------
    */

    private function verificationAccountIdentifier(
        Request $request
    ): ?string {
        $pendingUserId =
            $request->session()
                ->get('pending_user_id');

        if (
            is_int($pendingUserId) ||
            (
                is_string($pendingUserId) &&
                ctype_digit($pendingUserId)
            )
        ) {
            return 'user:' . $pendingUserId;
        }

        $email = $request->input('email');

        if (
            is_string($email) &&
            trim($email) !== ''
        ) {
            return hash(
                'sha256',
                mb_strtolower(
                    trim($email)
                )
            );
        }

        return null;
    }

    /*
    |--------------------------------------------------------------------------
    | CACHE KEY
    |--------------------------------------------------------------------------
    */

    private function key(
        string $type,
        ?string $value,
        ?string $route
    ): string {
        return 'adaptive-rate|' .
            $type . '|' .
            hash(
                'sha256',
                (string) $value
            ) . '|' .
            hash(
                'sha256',
                (string) $route
            );
    }

    /*
    |--------------------------------------------------------------------------
    | CONFIG HELPERS
    |--------------------------------------------------------------------------
    */

    private function requiredInt(
        array $config,
        string $key
    ): int {
        if (
            !array_key_exists(
                $key,
                $config
            ) ||
            !is_numeric($config[$key])
        ) {
            abort(
                500,
                "Missing rate-limit configuration: {$key}"
            );
        }

        return (int) $config[$key];
    }

    private function requiredArray(
        array $config,
        string $key
    ): array {
        if (
            !isset($config[$key]) ||
            !is_array($config[$key])
        ) {
            abort(
                500,
                "Missing rate-limit configuration section: {$key}"
            );
        }

        return $config[$key];
    }

    /*
    |--------------------------------------------------------------------------
    | 429 RESPONSE
    |--------------------------------------------------------------------------
    */

    private function tooManyRequests(
        int $retryAfter
    ): Response {
        if (request()->expectsJson()) {

            return response()
                ->json([
                    'message' =>
                        'Too many requests. Please try again later.',

                    'retry_after' =>
                        $retryAfter,
                ], 429)
                ->header(
                    'Retry-After',
                    (string) $retryAfter
                );
        }

        return response()
            ->view(
                'errors.too-many-requests',
                [
                    'retryAfter' =>
                        $retryAfter,
                ],
                429
            )
            ->header(
                'Retry-After',
                (string) $retryAfter
            );
    }
}